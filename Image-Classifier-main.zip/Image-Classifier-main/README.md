# Image-Classifier-Android-App
Android application that classifies images (selected from the phone's memory or taken with a camera). The image classification model is trained to recognize different classes of images. TensorFlow Lite provides optimized pre-trained models that can be deployed in the mobile application.

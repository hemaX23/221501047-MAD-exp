package com.example.scientificcalculator2;



import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView display;  // Changed from EditText to TextView
    private String input = "";
    private boolean isLastNumeric = false, isLastDot = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);  // No casting issues with TextView now

        setNumberButtonListeners();
        setOperatorButtonListeners();
    }

    private void setNumberButtonListeners() {
        int[] numberButtonIds = {R.id.button0, R.id.button1, R.id.button2, R.id.button3,
                R.id.button4, R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9, R.id.buttonDot};

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(v -> {
                Button button = (Button) v;
                if (button.getId() == R.id.buttonDot) {
                    if (!isLastDot && isLastNumeric) {
                        input += ".";
                        isLastDot = true;
                        isLastNumeric = false;
                    }
                } else {
                    input += button.getText().toString();
                    isLastNumeric = true;
                }
                display.setText(input);
            });
        }
    }

    private void setOperatorButtonListeners() {
        int[] operatorButtonIds = {R.id.buttonAdd, R.id.buttonSub, R.id.buttonMul, R.id.buttonDiv,
                R.id.buttonEqual, R.id.buttonClear, R.id.buttonSin, R.id.buttonCos, R.id.buttonTan};

        for (int id : operatorButtonIds) {
            findViewById(id).setOnClickListener(v -> {
                Button button = (Button) v;

                if (button.getId() == R.id.buttonClear) {
                    clear();
                } else if (button.getId() == R.id.buttonEqual) {
                    calculateResult();
                } else if (button.getId() == R.id.buttonSin) {
                    calculateTrigonometricFunction("sin");
                } else if (button.getId() == R.id.buttonCos) {
                    calculateTrigonometricFunction("cos");
                } else if (button.getId() == R.id.buttonTan) {
                    calculateTrigonometricFunction("tan");
                } else {
                    if (isLastNumeric) {
                        input += button.getText().toString();
                        isLastNumeric = false;
                        isLastDot = false;
                    }
                }

                display.setText(input);
            });
        }
    }

    private void clear() {
        input = "";
        display.setText("");
        isLastNumeric = false;
        isLastDot = false;
    }

    private void calculateResult() {
        try {
            double result = eval(input);
            display.setText(String.valueOf(result));
            input = String.valueOf(result);
        } catch (Exception e) {
            display.setText("Error");
            input = "";
        }
        isLastNumeric = false;
    }

    private void calculateTrigonometricFunction(String function) {
        try {
            double value = Double.parseDouble(input);
            double result = 0;
            switch (function) {
                case "sin":
                    result = Math.sin(Math.toRadians(value));
                    break;
                case "cos":
                    result = Math.cos(Math.toRadians(value));
                    break;
                case "tan":
                    result = Math.tan(Math.toRadians(value));
                    break;
            }
            display.setText(String.valueOf(result));
            input = String.valueOf(result);
        } catch (NumberFormatException e) {
            display.setText("Error");
            input = "";
        }
    }

    private double eval(String expression) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < expression.length()) throw new RuntimeException("Unexpected: " + (char) ch);
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                while (true) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                while (true) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();

                double x;
                int startPos = this.pos;
                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(expression.substring(startPos, this.pos));
                } else {
                    throw new RuntimeException("Unexpected: " + (char) ch);
                }

                return x;
            }
        }.parse();
    }
}

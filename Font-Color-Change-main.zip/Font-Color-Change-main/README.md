# Font-Color-Change
The user can enhances the change the font style and size in the application.
Users can control the size and font style of their own.

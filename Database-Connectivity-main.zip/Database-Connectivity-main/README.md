# Database-Connectivit
A detabase connectivity in an application is to perform a database operations. 
Access the credentials  for the database server like the connection parameters include such as Username,Password,GmailId,College name etc.
Required drivers and libraries for database connectivity.
Configure the database connectivity.
